#ifndef __zim_con__
#define __zim_con__

extern const short int debug = 1;

extern void mlog(char *, ...);
extern void mwarn(char *, ...);
extern void merror(char *, ...);
extern void mdebug(char *, ...);

#endif // __zim_con__
